
<template>
   <forgot-form/>
</template>
<script>
import ForgotPassword from "../../components/Login/ForgotPassword.vue"

export default{
    
    components: {
        'forgot-form': ForgotPassword,
    },
}
</script>