<template>
    <div class="w-full flex justify-start items-center">
        <img src="./../../assets/counting.png" class="animate-spin h-8 w-8 mr-3" viewBox="0 0 20 20">
        <p class="font-bold text-primary p-0 m-0">
            <slot></slot>
        </p>
    </div>
</template>