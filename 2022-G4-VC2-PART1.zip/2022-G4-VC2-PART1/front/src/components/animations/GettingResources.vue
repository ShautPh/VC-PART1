<template>
    <div class="w-full h-full flex justify-center items-center">
        <img src="./../../assets/getting_resources.gif" class="h-11 w-11 mr-3" viewBox="0 0 30 30">
        <p class="font-bold text-primary p-0 m-0">
            <slot></slot>
        </p>
    </div>
</template>