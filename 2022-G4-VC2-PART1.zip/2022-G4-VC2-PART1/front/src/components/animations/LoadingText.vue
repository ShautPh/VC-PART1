<template>
    <div>
        <div class="animate-pulse h-5 w-36 bg-slate-300 rounded-xl"></div>
    </div>
</template>