@component('mail::table') 
| Title           | Description         |
| ---------------- |:----------------:|
| Reason           | {{ $details['reason'] }}   |
| From Date        | {{ $details['start_date'] }}   |
| End Date         | {{ $details['end_time'] }}  |
| Duration         | {{ $details['leave_type'] }}              |
| Leave_type           | {{ $details['duration'] }}              |
| Status           | Panding              |
| Request Date     | February 20, 2018 7:00AM      |

@component('mail::button', ['url' => 'www.google.com'])
Button Text
@endcomponent