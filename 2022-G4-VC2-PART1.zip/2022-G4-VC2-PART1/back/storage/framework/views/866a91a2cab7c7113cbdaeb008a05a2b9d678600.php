<?php $__env->startComponent('mail::table'); ?> 
| Title           | Description         |
| ---------------- |:----------------:|
| Reason           | <?php echo e($details['reason']); ?>   |
| From Date        | <?php echo e($details['start_date']); ?>   |
| End Date         | <?php echo e($details['end_time']); ?>  |
| Duration         | <?php echo e($details['leave_type']); ?>              |
| Leave_type           | <?php echo e($details['duration']); ?>              |
| Status           | Panding              |
| Request Date     | February 20, 2018 7:00AM      |

<?php $__env->startComponent('mail::button', ['url' => 'www.google.com']); ?>
Button Text
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\sauth.phouek\Desktop\2022-G4-VC2-PART1\back\resources\views/welcome.blade.php ENDPATH**/ ?>